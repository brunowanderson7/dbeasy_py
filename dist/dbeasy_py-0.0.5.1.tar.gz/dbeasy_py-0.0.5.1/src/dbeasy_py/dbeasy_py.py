import sqlite3

def teste(n):
    return True